package socket.client;

import com.alibaba.fastjson.JSON;
import socket.Message;
import utils.FileUtils;

import java.io.File;

/**
 * TCP Socket客户端
 * 
 * @author jzj1993
 * @since 2015-2-22
 */
public class TcpClientImpl extends TcpClient {
	private SocketTransceiver client;

	@Override
	public void onConnect(SocketTransceiver transceiver) {
		System.out.println("已连接到服务端......");
	}

	@Override
	public void onConnectFailed() {
		System.out.println("连接失败......");
	}

	@Override
	public void onReceive(SocketTransceiver transceiver, String s) {
		System.out.println("接收到服务端数据：" + s);
		// 发送报文测试
		if(s.equals("1")) {
			String str = JSON.toJSONString(mockMessage());
			System.out.println(String.format("客户端发送报文长度：%s,内容=",s.length(),str));
			transceiver.send(str);
		}
	}

	@Override
	public void onDisconnect(SocketTransceiver transceiver) {
		System.out.println("与服务端断开了连接.....");
	}


	public Message mockMessage() {
		Message message = new Message();
		message.setType(1);
		File file = new File("/APP/image/2.jpg");
		String s = FileUtils.file2String(file,"UTF-8");
		message.setData(s);
		return message;
	}


}