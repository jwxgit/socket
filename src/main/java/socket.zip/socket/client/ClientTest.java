package socket.client;

public class ClientTest {
    public static void main(String args[]) {
        new TcpClientImpl().connect("192.168.199.110",10000);
    }
}
