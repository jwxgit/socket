package socket.server;

import com.alibaba.fastjson.JSON;
import socket.Message;
import utils.FileUtils;

import java.io.File;
import java.util.Scanner;

public class ServerTest {
    public static void main(String[] args) {
        TcpServerImpl tcp = new TcpServerImpl(10000);
        tcp.start();
        while(true) {
            try {
                System.out.println("控制台输入字符串开始");
                Scanner input =new Scanner(System.in);
                String instr = input.nextLine();
                if(instr.equals("1")) {
                    tcp.send("1");
                }
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }






}
